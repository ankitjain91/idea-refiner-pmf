import LandingPage from "./LandingPage";

const Index = () => {
  return <LandingPage />;
};

export default Index;