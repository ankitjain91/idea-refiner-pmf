import React from "react";

export class ErrorBoundary extends React.Component<{ fallback?: React.ReactNode }, { hasError: boolean }> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(err: any, info: any) {
    console.error("UI ErrorBoundary:", err, info);
  }
  render() {
    if (this.state.hasError) {
      return this.props.fallback ?? (
        <div className="rounded-2xl border p-4 text-sm">Something went wrong. Refresh or try again.</div>
      );
    }
    return this.props.children;
  }
}
